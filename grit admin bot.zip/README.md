# GRIT Learn — Admin Bot Setup

## الخطوات

### 1. إنشاء البوت على Telegram
- افتح @BotFather
- أرسل /newbot
- اختر اسم: GRIT Admin Bot
- اختر username: gritlearn_admin_bot
- انسخ التوكن

### 2. عدّل bot.py
```python
BOT_TOKEN    = "TOKEN_FROM_BOTFATHER"   # ← التوكن هنا
MAIN_ADMIN_ID = 123456789               # ← Telegram ID الخاص بك
ADMIN_IDS = {MAIN_ADMIN_ID}
```

### للحصول على Telegram ID الخاص بك:
- افتح @userinfobot وأرسل /start

### 3. رفع ملفات data/ على GitHub
ارفع هذه الملفات في مجلد data/ بالـ repo:
- data/quiz.json
- data/summaries.json
- data/exams.json
- data/sections.json
- data/announcements.json

### 4. تشغيل البوت
```bash
pip install -r requirements.txt
python bot.py
```

## هيكل الملفات على GitHub
```
gritlearn/
├── index.html
├── questions.js
└── data/
    ├── quiz.json
    ├── summaries.json
    ├── exams.json
    ├── sections.json
    └── announcements.json
```
